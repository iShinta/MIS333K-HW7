﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ho_MinhTri_HW7.Models
{
    public class Home
    {
    }
}